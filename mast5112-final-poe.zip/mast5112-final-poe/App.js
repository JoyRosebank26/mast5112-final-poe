import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button, FlatList, TouchableOpacity } from 'react-native';

export default function App() {
  
  const [currentScreen, setCurrentScreen] = useState('Home');
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [editingId, setEditingId] = useState(null);

  const [menuItems, setMenuItems] = useState([
    { id: '1', name: 'Grilled Steak', course: 'Main', price: 'R160' },
    { id: '2', name: 'Meatballs', course: 'Starter', price: 'R140' },
    { id: '3', name: 'Cheesecake', course: 'Dessert', price: 'R170' }
  ]);

  const totalItems = menuItems.length;

  const averagePrice = totalItems > 0 
    ? (menuItems.reduce((sum, item) => sum + parseFloat(item.price.replace('R', '')), 0) / totalItems).toFixed(2) 
    : '0.00';

  const starterCount = menuItems.filter(item => item.course.toLowerCase().includes('starter')).length;
  const mainCount = menuItems.filter(item => item.course.toLowerCase().includes('main')).length;
  const dessertCount = menuItems.filter(item => item.course.toLowerCase().includes('dessert')).length;

  const handleAddOrUpdateDish = () => {
    if (dishName && price) {
      if (editingId) {
        setMenuItems(prevItems =>
          prevItems.map(item =>
            item.id === editingId
              ? { ...item, name: dishName, course: description || 'Main', price: price.startsWith('R') ? price : `R${price}` }
              : item
          )
        );
        alert('Success: Dish updated successfully!');
        setEditingId(null);
    } else {

        const newItem = {
          id: Date.now().toString(),
          name: dishName,
          course: description || 'Main',
          price: price.startsWith('R') ? price : `R${price}`,
        };
        setMenuItems([...menuItems, newItem]);
        alert('Success: New dish added to the menu!');
      }
    
      setDishName('');
      setDescription('');
      setPrice('');
      setCurrentScreen('ViewMenu');
    } else {
      alert('Error: Please enter both a dish name and a price.');
    }
  };

  const handleDelete = (id) => {
 
    setMenuItems(prevItems => prevItems.filter(item => item.id !== id));
    alert('Success: Dish removed from the menu.');
  };

  const handleStartEdit = (item) => {
    setEditingId(item.id);
    setDishName(item.name);
    setDescription(item.course);
    setPrice(item.price.replace('R', ''));
    setCurrentScreen('AddDish');
  };

  const filteredItems = menuItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.course.toLowerCase().includes(searchQuery.toLowerCase());
    
    const itemCourse = item.course.toLowerCase().trim();
    const targetCategory = selectedCategory.toLowerCase().trim();
    
    const matchesCategory = selectedCategory === 'All' || itemCourse === targetCategory;
    
    return matchesSearch && matchesCategory;
  });

  if (currentScreen === 'Home') {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>CHEF'S MENU MANAGER</Text>
        <Text style={styles.counter}>Total Dishes : {menuItems.length}</Text>

        <View style={styles.buttonSpace}>
          <Button
            title="VIEW MENU"
            color="#5BC0DE"
            onPress={() => setCurrentScreen('ViewMenu')}
          />
        </View>

        <View style={styles.buttonSpace}>
          <Button
            title="ADD NEW DISH"
            color="#5BC0DE"
            onPress={() => {
              setEditingId(null);
              setDishName('');
              setDescription('');
              setPrice('');
              setCurrentScreen('AddDish');
            }}
          />
        </View>

        <View style={styles.buttonSpace}>
          <Button
            title="VIEW STATISTICS"
            color="#428BCA"
            onPress={() => setCurrentScreen('Statistics')}
          />
        </View>
      </View>
    );
  }

  if (currentScreen === 'AddDish') {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>{editingId ? 'EDIT DISH' : 'ADD NEW DISH'}</Text>

        <TextInput
          style={styles.input}
          placeholder="Dish Name"
          placeholderTextColor="#888"
          value={dishName}
          onChangeText={setDishName}
        />

        <TextInput
          style={styles.input}
          placeholder="Course (Starter, Main, Dessert)"
          placeholderTextColor="#888"
          value={description}
          onChangeText={setDescription}
        />

        <TextInput
          style={styles.input}
          placeholder="Price (R)"
          placeholderTextColor="#888"
          keyboardType="numeric"
          value={price}
          onChangeText={setPrice}
        />

        <View style={styles.buttonSpace}>
          <Button
            title={editingId ? "Save Changes" : "Add Dish"}
            color="#428BCA"
            onPress={handleAddOrUpdateDish}
          />
        </View>

        <View style={styles.buttonSpace}>
          <Button
            title="Back to Home"
            color="#888"
            onPress={() => setCurrentScreen('Home')}
          />
        </View>
      </View>
    );
  }

  if (currentScreen === 'ViewMenu') {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>VIEW MENU</Text>

        <TextInput
          style={styles.searchInput}
          placeholder="Search Dish Name..."
          placeholderTextColor="#888"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />

        <View style={styles.filterRow}>
          {['All', 'Starter', 'Main', 'Dessert'].map((category) => (
            <TouchableOpacity
              key={category}
              style={[
                styles.filterBtn,
                selectedCategory === category && styles.filterBtnActive
              ]}
              onPress={() => setSelectedCategory(category)}
            >
              <Text style={[styles.filterText, selectedCategory === category && styles.filterTextActive]}>
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <FlatList
          data={filteredItems}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.menuItemCard}>
              <Text style={styles.menuItemText}>
                {item.name} — {item.course} — {item.price}
              </Text>
              
              <View style={styles.actionRow}>
                <TouchableOpacity onPress={() => handleStartEdit(item)}>
                  <Text style={styles.actionTextEdit}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleDelete(item.id)}>
                  <Text style={styles.actionTextDelete}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          style={styles.list}
        />

        <View style={styles.buttonSpace}>
          <Button
            title="Back to Home"
            color="#888"
            onPress={() => setCurrentScreen('Home')}
          />
        </View>
      </View>
    );
  }

  if (currentScreen === 'Statistics') {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>MENU STATISTICS</Text>

        <View style={styles.statCard}>
          <Text style={styles.statText}>Total Menu Items: {totalItems}</Text>
          <Text style={styles.statText}>Average Price: R{averagePrice}</Text>
          <Text style={styles.statText}>Starters: {starterCount}</Text>
          <Text style={styles.statText}>Main Courses: {mainCount}</Text>
          <Text style={styles.statText}>Desserts: {dessertCount}</Text>
        </View>

        <View style={styles.buttonSpace}>
          <Button
            title="Back to Home"
            color="#888"
            onPress={() => setCurrentScreen('Home')}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 20,
    marginBottom: 20,
    fontWeight: 'bold',
  },
  counter: {
    fontSize: 16,
    backgroundColor: '#D3D3D3',
    padding: 10,
    width: '80%',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#D3D3D3',
    width: '80%',
    padding: 12,
    marginBottom: 15,
    borderRadius: 4,
    fontSize: 16,
  },
  searchInput: {
    fontSize: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#000',
    width: '80%',
    paddingBottom: 5,
    marginBottom: 12,
    textAlign: 'center',
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 15,
  },
  filterBtn: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    backgroundColor: '#D3D3D3',
    borderRadius: 4,
  },
  filterBtnActive: {
    backgroundColor: '#428BCA',
  },
  filterText: {
    fontSize: 11,
    color: '#000',
    fontWeight: 'bold',
  },
  filterTextActive: {
    color: '#FFF',
  },
  list: {
    width: '100%',
    maxHeight: 250,
    marginBottom: 15,
  },
  menuItemCard: {
    backgroundColor: '#5BC0DE',
    padding: 12,
    borderRadius: 4,
    width: '80%',
    alignSelf: 'center',
    marginBottom: 10,
  },
  menuItemText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  actionRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 8,
    gap: 15,
  },
  actionTextEdit: {
    color: '#FFF',
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  actionTextDelete: {
    color: '#FFD1D1',
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  statCard: {
    backgroundColor: '#D3D3D3',
    width: '80%',
    padding: 15,
    borderRadius: 4,
    marginBottom: 20,
  },
  statText: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
  },
  buttonSpace: {
    width: '80%',
    marginBottom: 15,
  },
});


 




































